/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.progwildlife;

import java.util.ArrayList;
import java.util.Scanner;

public class PROGWILDLIFE {

    // Used for the different rescue statuses
    enum RescueStatus {
        REGISTERED,
        IN_PROGRESS,
        COMPLETED
    }

    // Interface for rescue operations
    interface RescueOperations {
        void startRescue();
        void completeRescue();
        void displaySummary();
    }

    // Parent class for all rescue cases
    static abstract class RescueCase implements RescueOperations {
        private String caseId;
        private String animalName;
        private String species;
        private String location;
        private String ranger;
        private int rescueDays;
        private double dailyCareCost;
        private RescueStatus status;

        public RescueCase(String caseId, String animalName, String species,
                          String location, String ranger, int rescueDays,
                          double dailyCareCost) {
            this.caseId = caseId;
            this.animalName = animalName;
            this.species = species;
            this.location = location;
            this.ranger = ranger;
            this.rescueDays = rescueDays;
            this.dailyCareCost = dailyCareCost;
            this.status = RescueStatus.REGISTERED;
        }

        public String getCaseId() {
            return caseId;
        }

        public String getAnimalName() {
            return animalName;
        }

        public String getSpecies() {
            return species;
        }

        public String getLocation() {
            return location;
        }

        public String getRanger() {
            return ranger;
        }

        public int getRescueDays() {
            return rescueDays;
        }

        public double getDailyCareCost() {
            return dailyCareCost;
        }

        public RescueStatus getStatus() {
            return status;
        }

        protected void setStatus(RescueStatus status) {
            this.status = status;
        }

        // Each rescue type calculates these differently
        public abstract double calculateTotalCost();
        public abstract String calculatePriority();
        public abstract String getRescueType();
        public abstract void displaySpecificInformation();

        @Override
        public void startRescue() {
            status = RescueStatus.IN_PROGRESS;
            System.out.println("Rescue operation started.");
        }

        @Override
        public void completeRescue() {
            status = RescueStatus.COMPLETED;
            System.out.println("Rescue operation completed.");
        }

        @Override
        public void displaySummary() {
            System.out.println("\n----- Rescue Summary -----");
            System.out.println("Case ID: " + caseId);
            System.out.println("Rescue Type: " + getRescueType());
            System.out.println("Species: " + species);
            System.out.println("Assigned Ranger: " + ranger);
            System.out.println("Rescue Priority: " + calculatePriority());
            System.out.println("Current Status: " + status);
            System.out.printf("Total Rescue Cost: R%.2f%n", calculateTotalCost());
        }

        public void displayCase() {
            System.out.println("\n-----------------------------");
            System.out.println("Case ID: " + caseId);
            System.out.println("Animal Name: " + animalName);
            System.out.println("Rescue Type: " + getRescueType());
            System.out.println("Species: " + species);
            System.out.println("Location: " + location);
            System.out.println("Assigned Ranger: " + ranger);
            System.out.println("Rescue Days: " + rescueDays);
            System.out.printf("Daily Care Cost: R%.2f%n", dailyCareCost);
            System.out.println("Priority: " + calculatePriority());
            System.out.println("Status: " + status);
            System.out.printf("Total Cost: R%.2f%n", calculateTotalCost());
            displaySpecificInformation();
        }
    }

    // Injured animal rescue
    static class InjuredAnimalRescue extends RescueCase {
        private String injuryDescription;
        private double veterinaryTreatmentCost;
        private boolean surgeryRequired;

        public InjuredAnimalRescue(String caseId, String animalName, String species,
                                   String location, String ranger, int rescueDays,
                                   double dailyCareCost, String injuryDescription,
                                   double veterinaryTreatmentCost, boolean surgeryRequired) {
            super(caseId, animalName, species, location, ranger, rescueDays, dailyCareCost);
            this.injuryDescription = injuryDescription;
            this.veterinaryTreatmentCost = veterinaryTreatmentCost;
            this.surgeryRequired = surgeryRequired;
        }

        @Override
        public double calculateTotalCost() {
            double total = getRescueDays() * getDailyCareCost()
                    + veterinaryTreatmentCost;

            if (surgeryRequired) {
                total += 5000;
            }

            return total;
        }

        @Override
        public String calculatePriority() {
            if (surgeryRequired || veterinaryTreatmentCost >= 5000) {
                return "HIGH";
            }
            return "MEDIUM";
        }

        @Override
        public String getRescueType() {
            return "Injured Animal Rescue";
        }

        @Override
        public void displaySpecificInformation() {
            System.out.println("Injury Description: " + injuryDescription);
            System.out.printf("Veterinary Treatment Cost: R%.2f%n", veterinaryTreatmentCost);
            System.out.println("Surgery Required: " + (surgeryRequired ? "Yes" : "No"));
        }
    }

    // Orphaned animal rescue
    static class OrphanedAnimalRescue extends RescueCase {
        private int estimatedAgeMonths;
        private double feedingCost;
        private boolean fosterCareRequired;

        public OrphanedAnimalRescue(String caseId, String animalName, String species,
                                    String location, String ranger, int rescueDays,
                                    double dailyCareCost, int estimatedAgeMonths,
                                    double feedingCost, boolean fosterCareRequired) {
            super(caseId, animalName, species, location, ranger, rescueDays, dailyCareCost);
            this.estimatedAgeMonths = estimatedAgeMonths;
            this.feedingCost = feedingCost;
            this.fosterCareRequired = fosterCareRequired;
        }

        @Override
        public double calculateTotalCost() {
            double total = getRescueDays() * getDailyCareCost()
                    + feedingCost;

            if (fosterCareRequired) {
                total += 2500;
            }

            return total;
        }

        @Override
        public String calculatePriority() {
            if (estimatedAgeMonths <= 3 || fosterCareRequired) {
                return "HIGH";
            }
            return "MEDIUM";
        }

        @Override
        public String getRescueType() {
            return "Orphaned Animal Rescue";
        }

        @Override
        public void displaySpecificInformation() {
            System.out.println("Estimated Age: " + estimatedAgeMonths + " months");
            System.out.printf("Feeding Cost: R%.2f%n", feedingCost);
            System.out.println("Foster Care Required: " + (fosterCareRequired ? "Yes" : "No"));
        }
    }

    // Endangered species rescue
    static class EndangeredSpeciesRescue extends RescueCase {
        private String conservationClassification;
        private double securityCost;
        private boolean specialistTeamRequired;

        public EndangeredSpeciesRescue(String caseId, String animalName, String species,
                                       String location, String ranger, int rescueDays,
                                       double dailyCareCost, String conservationClassification,
                                       double securityCost, boolean specialistTeamRequired) {
            super(caseId, animalName, species, location, ranger, rescueDays, dailyCareCost);
            this.conservationClassification = conservationClassification;
            this.securityCost = securityCost;
            this.specialistTeamRequired = specialistTeamRequired;
        }

        @Override
        public double calculateTotalCost() {
            double total = getRescueDays() * getDailyCareCost()
                    + securityCost;

            if (specialistTeamRequired) {
                total += 8000;
            }

            return total;
        }

        @Override
        public String calculatePriority() {
            if (specialistTeamRequired ||
                    conservationClassification.equalsIgnoreCase("Critically Endangered")) {
                return "HIGH";
            }
            return "MEDIUM";
        }

        @Override
        public String getRescueType() {
            return "Endangered Species Rescue";
        }

        @Override
        public void displaySpecificInformation() {
            System.out.println("Conservation Classification: " + conservationClassification);
            System.out.printf("Security Cost: R%.2f%n", securityCost);
            System.out.println("Specialist Team Required: "
                    + (specialistTeamRequired ? "Yes" : "No"));
        }
    }

    // Manages all rescue cases
    static class RescueManager {
        private ArrayList<RescueCase> rescueCases = new ArrayList<>();

        public boolean addCase(RescueCase rescueCase) {
            if (findCase(rescueCase.getCaseId()) != null) {
                return false;
            }

            rescueCases.add(rescueCase);
            return true;
        }

        public RescueCase findCase(String caseId) {
            for (RescueCase rescueCase : rescueCases) {
                if (rescueCase.getCaseId().equalsIgnoreCase(caseId)) {
                    return rescueCase;
                }
            }
            return null;
        }

        public ArrayList<RescueCase> getRescueCases() {
            return rescueCases;
        }

        public void displayAllCases() {
            if (rescueCases.isEmpty()) {
                System.out.println("No rescue cases have been added.");
                return;
            }

            for (RescueCase rescueCase : rescueCases) {
                rescueCase.displayCase();
            }
        }

        public void generateReport() {
            double totalCost = 0;

            System.out.println("\n========================================");
            System.out.println("          WILDLIFE SA REPORT");
            System.out.println("========================================");

            if (rescueCases.isEmpty()) {
                System.out.println("No rescue cases available.");
                return;
            }

            for (RescueCase rescueCase : rescueCases) {
                System.out.println("\nCase ID: " + rescueCase.getCaseId());
                System.out.println("Rescue Type: " + rescueCase.getRescueType());
                System.out.println("Species: " + rescueCase.getSpecies());
                System.out.println("Location: " + rescueCase.getLocation());
                System.out.println("Assigned Ranger: " + rescueCase.getRanger());
                System.out.println("Priority: " + rescueCase.calculatePriority());
                System.out.println("Status: " + rescueCase.getStatus());
                System.out.printf("Total Rescue Cost: R%.2f%n",
                        rescueCase.calculateTotalCost());

                totalCost += rescueCase.calculateTotalCost();
            }

            System.out.println("\n----------------------------------------");
            System.out.println("Total Number of Cases: " + rescueCases.size());
            System.out.printf("Total Estimated Rescue Cost: R%.2f%n", totalCost);
            System.out.println("========================================");
        }
    }

    static Scanner scanner = new Scanner(System.in);
    static RescueManager manager = new RescueManager();

    public static void main(String[] args) {
        boolean running = true;

        while (running) {
            displayMenu();

            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    createRescueCase();
                    break;
                case 2:
                    searchCase();
                    break;
                case 3:
                    updateStatus();
                    break;
                case 4:
                    manager.displayAllCases();
                    break;
                case 5:
                    startRescue();
                    break;
                case 6:
                    completeRescue();
                    break;
                case 7:
                    showSummary();
                    break;
                case 8:
                    manager.generateReport();
                    break;
                case 9:
                    running = false;
                    System.out.println("Thank you for using WildLife SA.");
                    break;
                default:
                    System.out.println("Invalid menu option.");
            }
        }

        scanner.close();
    }

    public static void displayMenu() {
        System.out.println("\n========================================");
        System.out.println("       WILDLIFE SA RESCUE SYSTEM");
        System.out.println("========================================");
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status");
        System.out.println("4. Display All Rescue Cases");
        System.out.println("5. Start Rescue Operation");
        System.out.println("6. Complete Rescue Operation");
        System.out.println("7. Generate Rescue Summary");
        System.out.println("8. Generate Rescue Report");
        System.out.println("9. Exit");
        System.out.println("========================================");
    }

    public static void createRescueCase() {
        System.out.println("\n--- Create Rescue Case ---");

        String caseId = readRequiredString("Enter Rescue Case ID: ");

        if (manager.findCase(caseId) != null) {
            System.out.println("That Rescue Case ID already exists.");
            return;
        }

        String animalName = readRequiredString("Enter Animal Name: ");
        String species = readRequiredString("Enter Species: ");
        String location = readRequiredString("Enter Rescue Location: ");
        String ranger = readRequiredString("Enter Assigned Ranger: ");
        int rescueDays = readPositiveInt("Enter Number of Rescue Days: ");
        double dailyCost = readPositiveDouble("Enter Daily Care Cost: ");

        System.out.println("\nSelect Rescue Type:");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");

        int type = readInt("Enter rescue type: ");

        RescueCase rescueCase;

        switch (type) {
            case 1:
                String injury = readRequiredString("Enter Injury Description: ");
                double vetCost = readPositiveDouble("Enter Veterinary Treatment Cost: ");
                boolean surgery = readYesNo("Is surgery required? ");

                rescueCase = new InjuredAnimalRescue(
                        caseId, animalName, species, location, ranger,
                        rescueDays, dailyCost, injury, vetCost, surgery
                );
                break;

            case 2:
                int age = readPositiveInt("Enter Estimated Age in Months: ");
                double feedingCost = readPositiveDouble("Enter Feeding Cost: ");
                boolean foster = readYesNo("Is foster care required? ");

                rescueCase = new OrphanedAnimalRescue(
                        caseId, animalName, species, location, ranger,
                        rescueDays, dailyCost, age, feedingCost, foster
                );
                break;

            case 3:
                String classification = readRequiredString(
                        "Enter Conservation Classification: ");
                double securityCost = readPositiveDouble("Enter Security Cost: ");
                boolean specialist = readYesNo(
                        "Is a specialist team required? ");

                rescueCase = new EndangeredSpeciesRescue(
                        caseId, animalName, species, location, ranger,
                        rescueDays, dailyCost, classification,
                        securityCost, specialist
                );
                break;

            default:
                System.out.println("Invalid rescue type.");
                return;
        }

        if (manager.addCase(rescueCase)) {
            System.out.println("Rescue case added successfully.");
        } else {
            System.out.println("Could not add rescue case.");
        }
    }

    public static void searchCase() {
        String id = readRequiredString("Enter Rescue Case ID: ");
        RescueCase rescueCase = manager.findCase(id);

        if (rescueCase == null) {
            System.out.println("Rescue case not found.");
        } else {
            rescueCase.displayCase();
        }
    }

    public static void updateStatus() {
        String id = readRequiredString("Enter Rescue Case ID: ");
        RescueCase rescueCase = manager.findCase(id);

        if (rescueCase == null) {
            System.out.println("Rescue case not found.");
            return;
        }

        System.out.println("1. Registered");
        System.out.println("2. In Progress");
        System.out.println("3. Completed");

        int choice = readInt("Select new status: ");

        switch (choice) {
            case 1:
                rescueCase.setStatus(RescueStatus.REGISTERED);
                break;
            case 2:
                rescueCase.setStatus(RescueStatus.IN_PROGRESS);
                break;
            case 3:
                rescueCase.setStatus(RescueStatus.COMPLETED);
                break;
            default:
                System.out.println("Invalid status option.");
                return;
        }

        System.out.println("Status updated successfully.");
    }

    public static void startRescue() {
        String id = readRequiredString("Enter Rescue Case ID: ");
        RescueCase rescueCase = manager.findCase(id);

        if (rescueCase == null) {
            System.out.println("Rescue case not found.");
        } else {
            rescueCase.startRescue();
        }
    }

    public static void completeRescue() {
        String id = readRequiredString("Enter Rescue Case ID: ");
        RescueCase rescueCase = manager.findCase(id);

        if (rescueCase == null) {
            System.out.println("Rescue case not found.");
        } else {
            rescueCase.completeRescue();
        }
    }

    public static void showSummary() {
        String id = readRequiredString("Enter Rescue Case ID: ");
        RescueCase rescueCase = manager.findCase(id);

        if (rescueCase == null) {
            System.out.println("Rescue case not found.");
        } else {
            rescueCase.displaySummary();
        }
    }

    public static String readRequiredString(String message) {
        while (true) {
            System.out.print(message);
            String value = scanner.nextLine().trim();

            if (!value.isEmpty()) {
                return value;
            }

            System.out.println("This field cannot be blank.");
        }
    }

    public static int readInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    public static int readPositiveInt(String message) {
        while (true) {
            int value = readInt(message);

            if (value > 0) {
                return value;
            }

            System.out.println("Value must be greater than zero.");
        }
    }

    public static double readPositiveDouble(String message) {
        while (true) {
            try {
                System.out.print(message);
                double value = Double.parseDouble(scanner.nextLine().trim());

                if (value > 0) {
                    return value;
                }

                System.out.println("Value must be greater than zero.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid amount.");
            }
        }
    }

    public static boolean readYesNo(String message) {
        while (true) {
            System.out.print(message + " (Y/N): ");
            String answer = scanner.nextLine().trim();

            if (answer.equalsIgnoreCase("Y")) {
                return true;
            }

            if (answer.equalsIgnoreCase("N")) {
                return false;
            }

            System.out.println("Please enter Y or N.");
        }
    }
}
