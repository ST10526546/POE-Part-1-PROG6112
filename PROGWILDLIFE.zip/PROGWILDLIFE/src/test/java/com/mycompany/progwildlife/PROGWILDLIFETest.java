/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

package com.mycompany.progwildlife;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class PROGWILDLIFETest {

    // Tests injured rescue cost
    @Test
    void testInjuredAnimalRescueCost() {
        PROGWILDLIFE.InjuredAnimalRescue rescue =
                new PROGWILDLIFE.InjuredAnimalRescue(
                        "R001",
                        "Leo",
                        "Lion",
                        "Kruger Park",
                        "John",
                        2,
                        1000,
                        "Broken leg",
                        3000,
                        true
                );

        // (2 x 1000) + 3000 + 5000 surgery
        assertEquals(10000, rescue.calculateTotalCost(), 0.01);
    }

    // Tests priority calculation
    @Test
    void testRescuePriority() {
        PROGWILDLIFE.InjuredAnimalRescue rescue =
                new PROGWILDLIFE.InjuredAnimalRescue(
                        "R002",
                        "Max",
                        "Leopard",
                        "Limpopo",
                        "Sarah",
                        3,
                        500,
                        "Serious injury",
                        6000,
                        true
                );

        assertEquals("HIGH", rescue.calculatePriority());
    }

    // Tests rescue status updates
    @Test
    void testRescueStatusUpdate() {
        PROGWILDLIFE.OrphanedAnimalRescue rescue =
                new PROGWILDLIFE.OrphanedAnimalRescue(
                        "R003",
                        "Baby",
                        "Elephant",
                        "Mpumalanga",
                        "David",
                        5,
                        300,
                        2,
                        1000,
                        true
                );

        assertEquals(
                PROGWILDLIFE.RescueStatus.REGISTERED,
                rescue.getStatus()
        );

        rescue.startRescue();

        assertEquals(
                PROGWILDLIFE.RescueStatus.IN_PROGRESS,
                rescue.getStatus()
        );

        rescue.completeRescue();

        assertEquals(
                PROGWILDLIFE.RescueStatus.COMPLETED,
                rescue.getStatus()
        );
    }

    // Tests searching for an existing case
    @Test
    void testSearchForRescueCase() {
        PROGWILDLIFE.RescueManager manager =
                new PROGWILDLIFE.RescueManager();

        PROGWILDLIFE.OrphanedAnimalRescue rescue =
                new PROGWILDLIFE.OrphanedAnimalRescue(
                        "R004",
                        "Simba",
                        "Lion",
                        "Pretoria",
                        "Michael",
                        4,
                        400,
                        6,
                        1200,
                        false
                );

        manager.addCase(rescue);

        PROGWILDLIFE.RescueCase found =
                manager.findCase("R004");

        assertNotNull(found);
        assertEquals("R004", found.getCaseId());
    }

    // Tests that duplicate IDs are rejected
    @Test
    void testDuplicateRescueCaseId() {
        PROGWILDLIFE.RescueManager manager =
                new PROGWILDLIFE.RescueManager();

        PROGWILDLIFE.InjuredAnimalRescue firstCase =
                new PROGWILDLIFE.InjuredAnimalRescue(
                        "R005",
                        "Rocky",
                        "Rhino",
                        "Limpopo",
                        "Peter",
                        3,
                        600,
                        "Leg injury",
                        2000,
                        false
                );

        PROGWILDLIFE.InjuredAnimalRescue secondCase =
                new PROGWILDLIFE.InjuredAnimalRescue(
                        "R005",
                        "Bella",
                        "Rhino",
                        "Limpopo",
                        "Anna",
                        2,
                        500,
                        "Minor injury",
                        1000,
                        false
                );

        assertTrue(manager.addCase(firstCase));
        assertFalse(manager.addCase(secondCase));
    }
}