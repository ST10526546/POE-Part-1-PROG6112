package com.mycompany.hospitalpatientadmissionsystem;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;   

/*
 * MediCare Hospital Patient Admission System
 *
 * This program is used to register patients and manage the beds
 * in one hospital ward. There are 20 beds in the ward.
 */

public class HospitalPatientAdmissionSystem {

    // Scanner is used to get information entered by the user.
    static Scanner input = new Scanner(System.in);

    // This object handles the patient list and the beds.
    static HospitalManager hospital = new HospitalManager();

    public static void main(String[] args) {

        int choice;

        System.out.println("==============================================");
        System.out.println("     MEDICARE HOSPITAL ADMISSION SYSTEM");
        System.out.println("==============================================");

        do {
            showMenu();
            choice = getInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    registerPatient();
                    break;

                case 2:
                    searchPatient();
                    break;

                case 3:
                    updatePatient();
                    break;

                case 4:
                    deletePatient();
                    break;

                case 5:
                    hospital.displayAllPatients();
                    break;

                case 6:
                    allocateBed();
                    break;

                case 7:
                    releaseBed();
                    break;

                case 8:
                    hospital.displayWard();
                    break;

                case 9:
                    hospital.displayAvailableBeds();
                    break;

                case 10:
                    hospital.displayOccupiedBeds();
                    break;

                case 11:
                    hospital.displayReport();
                    break;

                case 12:
                    hospital.sortBySurname();
                    break;

                case 13:
                    hospital.sortByPatientId();
                    break;

                case 0:
                    System.out.println("Thank you for using the system.");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        } while (choice != 0);

        input.close();
    }

    /*
     * Displays the main menu.
     */
    public static void showMenu() {
        System.out.println("\n--------------- MAIN MENU ----------------");
        System.out.println("PATIENT MANAGEMENT");
        System.out.println("1. Register patient");
        System.out.println("2. Search for patient");
        System.out.println("3. Update patient");
        System.out.println("4. Delete patient");
        System.out.println("5. Display all patients");

        System.out.println("\nBED MANAGEMENT");
        System.out.println("6. Allocate bed");
        System.out.println("7. Release bed");
        System.out.println("8. Display ward layout");
        System.out.println("9. Display available beds");
        System.out.println("10. Display occupied beds");

        System.out.println("\nREPORTS AND SORTING");
        System.out.println("11. Ward report");
        System.out.println("12. Sort patients by surname");
        System.out.println("13. Sort patients by Patient ID");

        System.out.println("\n0. Exit");
        System.out.println("-------------------------------------------");
    }

    /*
     * Gets all the information needed to register a patient.
     */
    public static void registerPatient() {

        System.out.println("\n----------- REGISTER PATIENT --------------");

        String id = getText("Patient ID: ");

        // Patient IDs must be unique.
        if (hospital.findPatient(id) != null) {
            System.out.println("A patient with that ID already exists.");
            return;
        }

        String firstName = getText("First name: ");
        String lastName = getText("Last name: ");
        int age = getAge();
        String gender = getText("Gender: ");
        String condition = getText("Medical condition: ");

        PatientCategory category = getCategory();

        if (category == PatientCategory.INPATIENT) {

            String ward = getText("Ward number: ");

            /*
             * The bed is not assigned while registering the patient.
             * It is done separately using the Allocate Bed option.
             */
            Inpatient patient = new Inpatient(
                    id,
                    firstName,
                    lastName,
                    age,
                    gender,
                    condition,
                    category,
                    ward,
                    "Not Allocated"
            );

            hospital.addPatient(patient);

        } else {

            Patient patient = new Patient(
                    id,
                    firstName,
                    lastName,
                    age,
                    gender,
                    condition,
                    category
            );

            hospital.addPatient(patient);
        }

        System.out.println("Patient registered successfully.");
    }

    /*
     * Lets the user choose one of the three patient categories.
     */
    public static PatientCategory getCategory() {

        while (true) {
            System.out.println("\nPatient category:");
            System.out.println("1. Inpatient");
            System.out.println("2. Outpatient");
            System.out.println("3. Emergency");

            int choice = getInt("Choose category: ");

            if (choice == 1) {
                return PatientCategory.INPATIENT;
            } else if (choice == 2) {
                return PatientCategory.OUTPATIENT;
            } else if (choice == 3) {
                return PatientCategory.EMERGENCY;
            } else {
                System.out.println("Invalid category.");
            }
        }
    }

    /*
     * Searches for a patient using the Patient ID entered by the user.
     */
    public static void searchPatient() {

        System.out.println("\n------------- SEARCH PATIENT --------------");

        String id = getText("Enter Patient ID: ");
        Patient patient = hospital.findPatient(id);

        if (patient == null) {
            System.out.println("Patient was not found.");
        } else {
            patient.displayDetails();
        }
    }

    /*
     * Updates the details of an existing patient.
     */
    public static void updatePatient() {

        System.out.println("\n------------- UPDATE PATIENT --------------");

        String id = getText("Enter Patient ID: ");
        Patient patient = hospital.findPatient(id);

        if (patient == null) {
            System.out.println("Patient was not found.");
            return;
        }

        System.out.println("\nCurrent details:");
        patient.displayDetails();

        System.out.println("\nEnter the new details.");

        patient.setFirstName(getText("First name: "));
        patient.setLastName(getText("Last name: "));
        patient.setAge(getAge());
        patient.setGender(getText("Gender: "));
        patient.setMedicalCondition(getText("Medical condition: "));

        // Ward number is only needed for an Inpatient.
        if (patient instanceof Inpatient) {
            Inpatient inpatient = (Inpatient) patient;
            inpatient.setWardNumber(getText("Ward number: "));
        }

        System.out.println("Patient details updated.");
    }

    /*
     * Deletes a patient from the system.
     */
    public static void deletePatient() {

        System.out.println("\n------------- DELETE PATIENT --------------");

        String id = getText("Enter Patient ID: ");
        Patient patient = hospital.findPatient(id);

        if (patient == null) {
            System.out.println("Patient was not found.");
            return;
        }

        /*
         * If the patient has a bed, release it before deleting the patient.
         * This prevents the bed from staying marked as occupied.
         */
        if (patient instanceof Inpatient) {
            Inpatient inpatient = (Inpatient) patient;

            if (!inpatient.getBedNumber().equals("Not Allocated")) {
                hospital.releaseBed(inpatient.getBedNumber());
            }
        }

        hospital.deletePatient(id);
        System.out.println("Patient deleted.");
    }

    /*
     * Allocates a bed to an inpatient.
     */
    public static void allocateBed() {

        System.out.println("\n-------------- ALLOCATE BED ---------------");

        String id = getText("Enter Inpatient Patient ID: ");
        Patient patient = hospital.findPatient(id);

        if (patient == null) {
            System.out.println("Patient was not found.");
            return;
        }

        // Outpatients and Emergency patients cannot have ward beds.
        if (!(patient instanceof Inpatient)) {
            System.out.println("Only Inpatients can be allocated a bed.");
            return;
        }

        Inpatient inpatient = (Inpatient) patient;

        if (!inpatient.getBedNumber().equals("Not Allocated")) {
            System.out.println("This patient already has a bed.");
            return;
        }

        hospital.displayAvailableBeds();

        String bed = getText("Enter bed number (B01-B20): ");

        if (hospital.allocateBed(id, bed)) {
            System.out.println("Bed " + bed.toUpperCase() + " allocated successfully.");
        }
    }

    /*
     * Releases a bed when the patient is discharged.
     */
    public static void releaseBed() {

        System.out.println("\n--------------- RELEASE BED ----------------");

        String bed = getText("Enter bed number (B01-B20): ");

        if (hospital.releaseBed(bed)) {
            System.out.println("Bed " + bed.toUpperCase() + " has been released.");
        }
    }

    /*
     * Reads a number from the keyboard.
     * The try/catch prevents the program from crashing when letters are entered.
     */
    public static int getInt(String message) {

        while (true) {
            System.out.print(message);

            try {
                return Integer.parseInt(input.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    /*
     * Gets a patient's age and makes sure it is sensible.
     */
    public static int getAge() {

        while (true) {
            int age = getInt("Age: ");

            if (age >= 0 && age <= 120) {
                return age;
            }

            System.out.println("Please enter an age between 0 and 120.");
        }
    }

    /*
     * Gets text input and does not allow the user to leave it blank.
     */
    public static String getText(String message) {

        while (true) {
            System.out.print(message);
            String value = input.nextLine().trim();

            if (!value.isEmpty()) {
                return value;
            }

            System.out.println("This field cannot be empty.");
        }
    }
}


/*
 * These are the three categories of patients used by the system.
 */
enum PatientCategory {
    INPATIENT,
    OUTPATIENT,
    EMERGENCY
}


/*
 * Patient is the main/base class.
 *
 * Outpatients and Emergency patients use this class directly.
 * Inpatients use the Inpatient subclass below.
 */
class Patient {

    // Patient information is private to keep the class encapsulated.
    private String patientId;
    private String firstName;
    private String lastName;
    private int age;
    private String gender;
    private String medicalCondition;
    private PatientCategory category;

    public Patient(String patientId, String firstName, String lastName,
                    int age, String gender, String medicalCondition,
                    PatientCategory category) {

        this.patientId = patientId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.gender = gender;
        this.medicalCondition = medicalCondition;
        this.category = category;
    }

    // Getters
    public String getPatientId() {
        return patientId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public String getMedicalCondition() {
        return medicalCondition;
    }

    public PatientCategory getCategory() {
        return category;
    }

    // Setters
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setMedicalCondition(String medicalCondition) {
        this.medicalCondition = medicalCondition;
    }

    public void setCategory(PatientCategory category) {
        this.category = category;
    }

    /*
     * Displays the information for a normal Patient.
     * Inpatient overrides this method to add ward and bed details.
     */
    public void displayDetails() {

        System.out.println("-------------------------------------------");
        System.out.println("Patient ID:        " + patientId);
        System.out.println("First Name:        " + firstName);
        System.out.println("Last Name:         " + lastName);
        System.out.println("Age:               " + age);
        System.out.println("Gender:            " + gender);
        System.out.println("Medical Condition: " + medicalCondition);
        System.out.println("Category:          " + category);
        System.out.println("-------------------------------------------");
    }
}


/*
 * Inpatient is a Patient with extra information about the ward and bed.
 *
 * This demonstrates inheritance because Inpatient extends Patient.
 */
class Inpatient extends Patient {

    private String wardNumber;
    private String bedNumber;

    public Inpatient(String patientId, String firstName, String lastName,
                     int age, String gender, String medicalCondition,
                     PatientCategory category, String wardNumber,
                     String bedNumber) {

        // super() calls the Patient constructor.
        super(patientId, firstName, lastName, age, gender,
              medicalCondition, category);

        this.wardNumber = wardNumber;
        this.bedNumber = bedNumber;
    }

    public String getWardNumber() {
        return wardNumber;
    }

    public String getBedNumber() {
        return bedNumber;
    }

    public void setWardNumber(String wardNumber) {
        this.wardNumber = wardNumber;
    }

    public void setBedNumber(String bedNumber) {
        this.bedNumber = bedNumber;
    }

    /*
     * The Patient displayDetails() method is overridden here.
     * The normal patient information is displayed first and then
     * the extra inpatient information is added.
     */
    @Override
    public void displayDetails() {

        super.displayDetails();

        System.out.println("Ward Number:       " + wardNumber);
        System.out.println("Bed Number:        " + bedNumber);
        System.out.println("-------------------------------------------");
    }
}


/*
 * HospitalManager stores and manages the patients and beds.
 */
class HospitalManager {

    /*
     * The ward is represented by a 4 x 5 two-dimensional array.
     *
     * null means that a bed is available.
     * A Patient ID means that the bed is occupied.
     */
    private String[][] beds = new String[4][5];

    // ArrayList is used to keep all registered patients in memory.
    private List<Patient> patients = new ArrayList<>();

    /*
     * Adds a patient to the list.
     */
  public void addPatient(Patient patient) {

    if (findPatient(patient.getPatientId()) != null) {
        throw new IllegalArgumentException(
                "A patient with that ID already exists."
        );
    }

    patients.add(patient);
}

    /*
     * Finds a patient by Patient ID.
     */
    public Patient findPatient(String id) {

        for (Patient patient : patients) {

            if (patient.getPatientId().equalsIgnoreCase(id)) {
                return patient;
            }
        }

        return null;
    }

    /*
     * Removes a patient from the patient list.
     */
    public boolean deletePatient(String id) {

        Patient patient = findPatient(id);

        if (patient != null) {
            patients.remove(patient);
            return true;
        }

        return false;
    }

    /*
     * Displays all registered patients.
     */
    public void displayAllPatients() {

        System.out.println("\n=========== ALL PATIENTS ===========");

        if (patients.isEmpty()) {
            System.out.println("There are no registered patients.");
            return;
        }

        for (Patient patient : patients) {
            patient.displayDetails();
        }
    }

    /*
     * Changes a bed number such as B01 into its row and column
     * position in the 4 x 5 array.
     */
    private int[] getBedPosition(String bedNumber) {

        if (bedNumber == null) {
            return null;
        }

        bedNumber = bedNumber.trim().toUpperCase();

        if (!bedNumber.matches("B(0[1-9]|1[0-9]|20)")) {
            return null;
        }

        int number = Integer.parseInt(bedNumber.substring(1));

        int row = (number - 1) / 5;
        int column = (number - 1) % 5;

        return new int[]{row, column};
    }

    /*
     * Allocates a free bed to a patient.
     */
    public boolean allocateBed(String patientId, String bedNumber) {

        Patient patient = findPatient(patientId);

        if (patient == null) {
            System.out.println("Patient does not exist.");
            return false;
        }

        if (!(patient instanceof Inpatient)) {
            System.out.println("Only Inpatients can use beds.");
            return false;
        }

        int[] position = getBedPosition(bedNumber);

        if (position == null) {
            System.out.println("Invalid bed number. Please use B01 to B20.");
            return false;
        }

        int row = position[0];
        int column = position[1];

        // A non-null value means another patient already has the bed.
        if (beds[row][column] != null) {
            System.out.println("That bed is already occupied.");
            return false;
        }

        Inpatient inpatient = (Inpatient) patient;

        if (!inpatient.getBedNumber().equals("Not Allocated")) {
            System.out.println("This patient already has a bed.");
            return false;
        }

        beds[row][column] = patientId;
        inpatient.setBedNumber(bedNumber.toUpperCase());

        return true;
    }

    /*
     * Releases an occupied bed.
     */
    public boolean releaseBed(String bedNumber) {

        int[] position = getBedPosition(bedNumber);

        if (position == null) {
            System.out.println("Invalid bed number. Please use B01 to B20.");
            return false;
        }

        int row = position[0];
        int column = position[1];

        if (beds[row][column] == null) {
            System.out.println("That bed is already available.");
            return false;
        }

        String patientId = beds[row][column];
        Patient patient = findPatient(patientId);

        if (patient instanceof Inpatient) {
            Inpatient inpatient = (Inpatient) patient;
            inpatient.setBedNumber("Not Allocated");
        }

        beds[row][column] = null;

        return true;
    }

    /*
     * Displays the 4 x 5 ward layout.
     */
    public void displayWard() {

        System.out.println("\n================ WARD ================");
        System.out.println("[ ] = Available     [X] = Occupied\n");

        // Nested loops are used because beds is a 2D array.
        for (int row = 0; row < beds.length; row++) {

            for (int column = 0; column < beds[row].length; column++) {

                int number = row * 5 + column + 1;
                String bed = String.format("B%02d", number);

                if (beds[row][column] == null) {
                    System.out.print("[" + bed + " - ]  ");
                } else {
                    System.out.print("[" + bed + " - X]  ");
                }
            }

            System.out.println();
        }
    }

    /*
     * Displays all the beds which are currently available.
     */
    public void displayAvailableBeds() {

        System.out.println("\n=========== AVAILABLE BEDS ===========");

        int count = 0;

        for (int row = 0; row < beds.length; row++) {

            for (int column = 0; column < beds[row].length; column++) {

                if (beds[row][column] == null) {

                    int number = row * 5 + column + 1;

                    System.out.print(String.format("B%02d ", number));
                    count++;
                }
            }
        }

        System.out.println();

        if (count == 0) {
            System.out.println("There are no available beds.");
        } else {
            System.out.println("Available beds: " + count);
        }
    }

    /*
     * Displays all occupied beds and the Patient ID using each bed.
     */
    public void displayOccupiedBeds() {

        System.out.println("\n=========== OCCUPIED BEDS ===========");

        int count = 0;

        for (int row = 0; row < beds.length; row++) {

            for (int column = 0; column < beds[row].length; column++) {

                if (beds[row][column] != null) {

                    int number = row * 5 + column + 1;

                    System.out.println(
                            String.format(
                                    "B%02d -> Patient ID: %s",
                                    number,
                                    beds[row][column]
                            )
                    );

                    count++;
                }
            }
        }

        if (count == 0) {
            System.out.println("There are no occupied beds.");
        }

        System.out.println("Occupied beds: " + count);
    }

    /*
     * Counts how many beds are occupied.
     */
    public int getOccupiedBeds() {

        int count = 0;

        for (int row = 0; row < beds.length; row++) {
            for (int column = 0; column < beds[row].length; column++) {

                if (beds[row][column] != null) {
                    count++;
                }
            }
        }

        return count;
    }

    /*
     * Creates the basic ward report required by the assignment.
     */
    public void displayReport() {

        int occupied = getOccupiedBeds();
        int available = 20 - occupied;

        double percentage = (occupied / 20.0) * 100;

        System.out.println("\n============= WARD REPORT =============");
        System.out.println("Registered patients: " + patients.size());
        System.out.println("Occupied beds:       " + occupied);
        System.out.println("Available beds:      " + available);
        System.out.printf("Ward occupancy:      %.2f%%%n", percentage);
        System.out.println("========================================");
    }

    /*
     * Displays the patients alphabetically by surname.
     */
    public void sortBySurname() {

        System.out.println("\n======= PATIENTS SORTED BY SURNAME =======");

        if (patients.isEmpty()) {
            System.out.println("There are no registered patients.");
            return;
        }

        // A copy is sorted so the original list is not changed.
        List<Patient> sortedPatients = new ArrayList<>(patients);

        sortedPatients.sort(
                Comparator.comparing(
                        Patient::getLastName,
                        String.CASE_INSENSITIVE_ORDER
                )
        );

        for (Patient patient : sortedPatients) {
            patient.displayDetails();
        }
    }

    /*
     * Displays the patients in Patient ID order.
     */
    public void sortByPatientId() {

        System.out.println("\n======= PATIENTS SORTED BY PATIENT ID =======");

        if (patients.isEmpty()) {
            System.out.println("There are no registered patients.");
            return;
        }

        List<Patient> sortedPatients = new ArrayList<>(patients);

        sortedPatients.sort(
                Comparator.comparing(
                        Patient::getPatientId,
                        String.CASE_INSENSITIVE_ORDER
                )
        );

        for (Patient patient : sortedPatients) {
            patient.displayDetails();
        }
    }
}
