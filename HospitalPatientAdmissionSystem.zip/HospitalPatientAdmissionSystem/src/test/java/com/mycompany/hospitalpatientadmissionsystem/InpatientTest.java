package com.mycompany.hospitalpatientadmissionsystem;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class InpatientTest {

    private Inpatient inpatient;

    @BeforeEach
    void setUp() {

        inpatient = new Inpatient(
                "P100",
                "Alice",
                "Brown",
                60,
                "Female",
                "Pneumonia",
                PatientCategory.INPATIENT,
                "1",
                "B01"
        );
    }

    @Test
    void shouldCreateInpatient() {

        assertNotNull(inpatient);
    }

    @Test
    void inpatientShouldExtendPatient() {

        assertTrue(inpatient instanceof Patient);
    }

    @Test
    void shouldInheritPatientId() {

        assertEquals(
                "P100",
                inpatient.getPatientId()
        );
    }

    @Test
    void shouldInheritFirstName() {

        assertEquals(
                "Alice",
                inpatient.getFirstName()
        );
    }

    @Test
    void shouldInheritLastName() {

        assertEquals(
                "Brown",
                inpatient.getLastName()
        );
    }

    @Test
    void shouldInheritAge() {

        assertEquals(
                60,
                inpatient.getAge()
        );
    }

    @Test
    void shouldInheritGender() {

        assertEquals(
                "Female",
                inpatient.getGender()
        );
    }

    @Test
    void shouldInheritMedicalCondition() {

        assertEquals(
                "Pneumonia",
                inpatient.getMedicalCondition()
        );
    }

    @Test
    void shouldHaveInpatientCategory() {

        assertEquals(
                PatientCategory.INPATIENT,
                inpatient.getCategory()
        );
    }

    @Test
    void shouldStoreWardNumber() {

        assertEquals(
                "1",
                inpatient.getWardNumber()
        );
    }

    @Test
    void shouldStoreBedNumber() {

        assertEquals(
                "B01",
                inpatient.getBedNumber()
        );
    }

    @Test
    void shouldUpdateWardNumber() {

        inpatient.setWardNumber("2");

        assertEquals(
                "2",
                inpatient.getWardNumber()
        );
    }

    @Test
    void shouldUpdateBedNumber() {

        inpatient.setBedNumber("B10");

        assertEquals(
                "B10",
                inpatient.getBedNumber()
        );
    }

    @Test
    void displayDetailsShouldIncludeWardAndBed() {

        ByteArrayOutputStream output =
                new ByteArrayOutputStream();

        PrintStream originalOut = System.out;

        System.setOut(new PrintStream(output));

        try {
            inpatient.displayDetails();
        } finally {
            System.setOut(originalOut);
        }

        String result = output.toString();

        assertTrue(result.contains("P100"));
        assertTrue(result.contains("Alice"));
        assertTrue(result.contains("Brown"));
        assertTrue(result.contains("1"));
        assertTrue(result.contains("B01"));
    }
}
