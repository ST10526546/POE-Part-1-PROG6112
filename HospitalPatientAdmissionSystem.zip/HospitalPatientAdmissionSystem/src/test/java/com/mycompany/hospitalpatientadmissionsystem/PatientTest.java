package com.mycompany.hospitalpatientadmissionsystem;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PatientTest {

    private Patient patient;

    @BeforeEach
    void setUp() {

        patient = new Patient(
                "P001",
                "John",
                "Smith",
                45,
                "Male",
                "Diabetes",
                PatientCategory.OUTPATIENT
        );
    }

    @Test
    void shouldCreatePatient() {

        assertNotNull(patient);
    }

    @Test
    void shouldStorePatientId() {

        assertEquals(
                "P001",
                patient.getPatientId()
        );
    }

    @Test
    void shouldStoreFirstName() {

        assertEquals(
                "John",
                patient.getFirstName()
        );
    }

    @Test
    void shouldStoreLastName() {

        assertEquals(
                "Smith",
                patient.getLastName()
        );
    }

    @Test
    void shouldStoreAge() {

        assertEquals(
                45,
                patient.getAge()
        );
    }

    @Test
    void shouldStoreGender() {

        assertEquals(
                "Male",
                patient.getGender()
        );
    }

    @Test
    void shouldStoreMedicalCondition() {

        assertEquals(
                "Diabetes",
                patient.getMedicalCondition()
        );
    }

    @Test
    void shouldStorePatientCategory() {

        assertEquals(
                PatientCategory.OUTPATIENT,
                patient.getCategory()
        );
    }

    @Test
    void shouldUpdateFirstName() {

        patient.setFirstName("James");

        assertEquals(
                "James",
                patient.getFirstName()
        );
    }

    @Test
    void shouldUpdateLastName() {

        patient.setLastName("Johnson");

        assertEquals(
                "Johnson",
                patient.getLastName()
        );
    }

    @Test
    void shouldUpdateAge() {

        patient.setAge(50);

        assertEquals(
                50,
                patient.getAge()
        );
    }

    @Test
    void shouldUpdateGender() {

        patient.setGender("Female");

        assertEquals(
                "Female",
                patient.getGender()
        );
    }

    @Test
    void shouldUpdateMedicalCondition() {

        patient.setMedicalCondition("Hypertension");

        assertEquals(
                "Hypertension",
                patient.getMedicalCondition()
        );
    }

    @Test
    void shouldUpdatePatientCategory() {

        patient.setCategory(PatientCategory.EMERGENCY);

        assertEquals(
                PatientCategory.EMERGENCY,
                patient.getCategory()
        );
    }

    @Test
    void displayDetailsShouldDisplayPatientInformation() {

        ByteArrayOutputStream output =
                new ByteArrayOutputStream();

        PrintStream originalOut = System.out;

        System.setOut(new PrintStream(output));

        try {
            patient.displayDetails();
        } finally {
            System.setOut(originalOut);
        }

        String result = output.toString();

        assertTrue(result.contains("P001"));
        assertTrue(result.contains("John"));
        assertTrue(result.contains("Smith"));
        assertTrue(result.contains("45"));
        assertTrue(result.contains("Male"));
        assertTrue(result.contains("Diabetes"));
        assertTrue(result.contains("OUTPATIENT"));
    }
}
