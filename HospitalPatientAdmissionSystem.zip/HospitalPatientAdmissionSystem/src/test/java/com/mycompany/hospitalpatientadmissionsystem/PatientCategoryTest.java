
package com.mycompany.hospitalpatientadmissionsystem;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PatientCategoryTest {

    @Test
    void shouldHaveInpatientCategory() {
        assertNotNull(PatientCategory.INPATIENT);
    }

    @Test
    void shouldHaveOutpatientCategory() {
        assertNotNull(PatientCategory.OUTPATIENT);
    }

    @Test
    void shouldHaveEmergencyCategory() {
        assertNotNull(PatientCategory.EMERGENCY);
    }

    @Test
    void shouldHaveExactlyThreeCategories() {
        assertEquals(3, PatientCategory.values().length);
    }

    @Test
    void shouldContainCorrectCategories() {

        assertArrayEquals(
                new PatientCategory[] {
                        PatientCategory.INPATIENT,
                        PatientCategory.OUTPATIENT,
                        PatientCategory.EMERGENCY
                },
                PatientCategory.values()
        );
    }
}
