package com.mycompany.hospitalpatientadmissionsystem;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class HospitalManagerTest {

    private HospitalManager hospital;

    @BeforeEach
    void setUp() {
        hospital = new HospitalManager();
    }

    private Patient createPatient(String id, String firstName, String lastName) {
        return new Patient(
                id,
                firstName,
                lastName,
                30,
                "Male",
                "Flu",
                PatientCategory.OUTPATIENT
        );
    }

    private Inpatient createInpatient(String id, String firstName, String lastName) {
        return new Inpatient(
                id,
                firstName,
                lastName,
                40,
                "Female",
                "Fever",
                PatientCategory.INPATIENT,
                "Ward 1",
                "Not Allocated"
        );
    }

    // -------------------------------------------------
    // 1. Register a patient
    // -------------------------------------------------
    @Test
    void shouldRegisterPatient() {

        Patient patient = createPatient(
                "P001",
                "John",
                "Smith"
        );

        hospital.addPatient(patient);

        assertNotNull(hospital.findPatient("P001"));
    }

    // -------------------------------------------------
    // 2. Search for a patient
    // -------------------------------------------------
    @Test
    void shouldSearchForPatient() {

        Patient patient = createPatient(
                "P002",
                "Mary",
                "Jones"
        );

        hospital.addPatient(patient);

        Patient found = hospital.findPatient("P002");

        assertNotNull(found);
        assertEquals("Mary", found.getFirstName());
        assertEquals("Jones", found.getLastName());
    }

    // -------------------------------------------------
    // 3. Search for a patient that does not exist
    // -------------------------------------------------
    @Test
    void shouldReturnNullWhenPatientDoesNotExist() {

        Patient found = hospital.findPatient("P999");

        assertNull(found);
    }

    // -------------------------------------------------
    // 4. Delete a patient
    // -------------------------------------------------
    @Test
    void shouldDeletePatient() {

        Patient patient = createPatient(
                "P003",
                "David",
                "Brown"
        );

        hospital.addPatient(patient);

        boolean deleted = hospital.deletePatient("P003");

        assertTrue(deleted);
        assertNull(hospital.findPatient("P003"));
    }

    // -------------------------------------------------
    // 5. Prevent duplicate Patient IDs
    // -------------------------------------------------
    @Test
    void shouldPreventDuplicatePatientIds() {

        Patient first = createPatient(
                "P004",
                "John",
                "Smith"
        );

        Patient second = createPatient(
                "P004",
                "Peter",
                "Jones"
        );

        hospital.addPatient(first);

        assertThrows(
                IllegalArgumentException.class,
                () -> hospital.addPatient(second)
        );
    }

    // -------------------------------------------------
    // 6. Allocate a bed
    // -------------------------------------------------
    @Test
    void shouldAllocateBedToInpatient() {

        Inpatient patient = createInpatient(
                "P005",
                "Sarah",
                "Williams"
        );

        hospital.addPatient(patient);

        boolean allocated =
                hospital.allocateBed("P005", "B01");

        assertTrue(allocated);
        assertEquals("B01", patient.getBedNumber());
        assertEquals(1, hospital.getOccupiedBeds());
    }

    // -------------------------------------------------
    // 7. Release a bed
    // -------------------------------------------------
    @Test
    void shouldReleaseBed() {

        Inpatient patient = createInpatient(
                "P006",
                "James",
                "Taylor"
        );

        hospital.addPatient(patient);

        hospital.allocateBed("P006", "B01");

        boolean released =
                hospital.releaseBed("B01");

        assertTrue(released);
        assertEquals("Not Allocated", patient.getBedNumber());
        assertEquals(0, hospital.getOccupiedBeds());
    }

    // -------------------------------------------------
    // 8. Prevent allocating an occupied bed
    // -------------------------------------------------
    @Test
    void shouldPreventAllocatingOccupiedBed() {

        Inpatient patient1 = createInpatient(
                "P007",
                "Tom",
                "Brown"
        );

        Inpatient patient2 = createInpatient(
                "P008",
                "Lisa",
                "Green"
        );

        hospital.addPatient(patient1);
        hospital.addPatient(patient2);

        assertTrue(
                hospital.allocateBed("P007", "B01")
        );

        assertFalse(
                hospital.allocateBed("P008", "B01")
        );

        assertEquals(
                "Not Allocated",
                patient2.getBedNumber()
        );

        assertEquals(
                1,
                hospital.getOccupiedBeds()
        );
    }

    // -------------------------------------------------
    // 9. Prevent outpatient from getting a bed
    // -------------------------------------------------
    @Test
    void shouldPreventOutpatientFromGettingBed() {

        Patient patient = createPatient(
                "P009",
                "Anna",
                "White"
        );

        hospital.addPatient(patient);

        assertFalse(
                hospital.allocateBed("P009", "B01")
        );

        assertEquals(
                0,
                hospital.getOccupiedBeds()
        );
    }

    // -------------------------------------------------
    // 10. Prevent allocation when all 20 beds are occupied
    // -------------------------------------------------
    @Test
    void shouldPreventAllocationWhenAllBedsAreOccupied() {

        // Fill all 20 beds
        for (int i = 1; i <= 20; i++) {

            String id = String.format("P%03d", i);
            String bed = String.format("B%02d", i);

            Inpatient patient = createInpatient(
                    id,
                    "Patient",
                    "Test" + i
            );

            hospital.addPatient(patient);

            assertTrue(
                    hospital.allocateBed(id, bed)
            );
        }

        assertEquals(
                20,
                hospital.getOccupiedBeds()
        );

        // Create another inpatient
        Inpatient extraPatient = createInpatient(
                "P021",
                "Extra",
                "Patient"
        );

        hospital.addPatient(extraPatient);

        // No bed should be available
        assertFalse(
                hospital.allocateBed("P021", "B01")
        );

        assertEquals(
                "Not Allocated",
                extraPatient.getBedNumber()
        );

        assertEquals(
                20,
                hospital.getOccupiedBeds()
        );
    }

    // -------------------------------------------------
    // 11. Prevent same patient from getting two beds
    // -------------------------------------------------
    @Test
    void shouldPreventPatientFromHavingTwoBeds() {

        Inpatient patient = createInpatient(
                "P022",
                "Michael",
                "Adams"
        );

        hospital.addPatient(patient);

        assertTrue(
                hospital.allocateBed("P022", "B01")
        );

        assertFalse(
                hospital.allocateBed("P022", "B02")
        );

        assertEquals(
                "B01",
                patient.getBedNumber()
        );

        assertEquals(
                1,
                hospital.getOccupiedBeds()
        );
    }

    // -------------------------------------------------
    // 12. Invalid bed number
    // -------------------------------------------------
    @Test
    void shouldRejectInvalidBedNumber() {

        Inpatient patient = createInpatient(
                "P023",
                "Robert",
                "Miller"
        );

        hospital.addPatient(patient);

        assertFalse(
                hospital.allocateBed("P023", "B21")
        );

        assertEquals(
                0,
                hospital.getOccupiedBeds()
        );
    }
}
