package com.mycompany.hospitalpatientadmissionsystem;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class HospitalPatientAdmissionTest {

    private HospitalManager hospital;

    @BeforeEach
    void setUp() {

        hospital = new HospitalManager();
    }

    private Inpatient createInpatient(
            String id,
            String firstName,
            String lastName) {

        return new Inpatient(
                id,
                firstName,
                lastName,
                40,
                "Male",
                "Diabetes",
                PatientCategory.INPATIENT,
                "1",
                "Not Allocated"
        );
    }

    @Test
    void shouldHave20BedsInitially() {

        /*
         * There should be 20 available beds in a
         * newly-created HospitalManager.
         *
         * We test this by allocating each bed and
         * confirming that all 20 can be allocated.
         */

        for (int i = 1; i <= 20; i++) {

            String id =
                    String.format("P%03d", i);

            String bed =
                    String.format("B%02d", i);

            Inpatient patient =
                    createInpatient(
                            id,
                            "Patient",
                            "Number" + i
                    );

            hospital.addPatient(patient);

            assertTrue(
                    hospital.allocateBed(id, bed)
            );
        }

        assertEquals(
                20,
                hospital.getOccupiedBeds()
        );
    }

    @Test
    void shouldAllocateBedToInpatient() {

        Inpatient patient =
                createInpatient(
                        "P001",
                        "John",
                        "Smith"
                );

        hospital.addPatient(patient);

        boolean allocated =
                hospital.allocateBed(
                        "P001",
                        "B01"
                );

        assertTrue(allocated);

        assertEquals(
                "B01",
                patient.getBedNumber()
        );

        assertEquals(
                1,
                hospital.getOccupiedBeds()
        );
    }

    @Test
    void shouldReleaseBed() {

        Inpatient patient =
                createInpatient(
                        "P002",
                        "Mary",
                        "Jones"
                );

        hospital.addPatient(patient);

        assertTrue(
                hospital.allocateBed(
                        "P002",
                        "B01"
                )
        );

        assertEquals(
                1,
                hospital.getOccupiedBeds()
        );

        boolean released =
                hospital.releaseBed("B01");

        assertTrue(released);

        assertEquals(
                0,
                hospital.getOccupiedBeds()
        );

        assertEquals(
                "Not Allocated",
                patient.getBedNumber()
        );
    }

    @Test
    void shouldPreventAllocatingOccupiedBed() {

        Inpatient firstPatient =
                createInpatient(
                        "P003",
                        "John",
                        "Smith"
                );

        Inpatient secondPatient =
                createInpatient(
                        "P004",
                        "Mary",
                        "Jones"
                );

        hospital.addPatient(firstPatient);
        hospital.addPatient(secondPatient);

        assertTrue(
                hospital.allocateBed(
                        "P003",
                        "B01"
                )
        );

        boolean allocated =
                hospital.allocateBed(
                        "P004",
                        "B01"
                );

        assertFalse(allocated);

        assertEquals(
                1,
                hospital.getOccupiedBeds()
        );

        assertEquals(
                "Not Allocated",
                secondPatient.getBedNumber()
        );
    }

    @Test
    void shouldPreventOutpatientFromReceivingBed() {

        Patient outpatient =
                new Patient(
                        "P005",
                        "Sarah",
                        "Wilson",
                        35,
                        "Female",
                        "Asthma",
                        PatientCategory.OUTPATIENT
                );

        hospital.addPatient(outpatient);

        boolean allocated =
                hospital.allocateBed(
                        "P005",
                        "B01"
                );

        assertFalse(allocated);

        assertEquals(
                0,
                hospital.getOccupiedBeds()
        );
    }

    @Test
    void shouldPreventEmergencyPatientFromReceivingBed() {

        Patient emergency =
                new Patient(
                        "P006",
                        "David",
                        "Taylor",
                        50,
                        "Male",
                        "Injury",
                        PatientCategory.EMERGENCY
                );

        hospital.addPatient(emergency);

        boolean allocated =
                hospital.allocateBed(
                        "P006",
                        "B01"
                );

        assertFalse(allocated);

        assertEquals(
                0,
                hospital.getOccupiedBeds()
        );
    }

    @Test
    void shouldPreventOneInpatientFromHavingTwoBeds() {

        Inpatient patient =
                createInpatient(
                        "P007",
                        "Alice",
                        "Brown"
                );

        hospital.addPatient(patient);

        assertTrue(
                hospital.allocateBed(
                        "P007",
                        "B01"
                )
        );

        boolean secondAllocation =
                hospital.allocateBed(
                        "P007",
                        "B02"
                );

        assertFalse(secondAllocation);

        assertEquals(
                "B01",
                patient.getBedNumber()
        );

        assertEquals(
                1,
                hospital.getOccupiedBeds()
        );
    }

    @Test
    void shouldPreventAllocationWhenAll20BedsAreOccupied() {

        // Fill B01 to B20.
        for (int i = 1; i <= 20; i++) {

            String patientId =
                    String.format("P%03d", i);

            String bedNumber =
                    String.format("B%02d", i);

            Inpatient patient =
                    createInpatient(
                            patientId,
                            "Patient",
                            "Number" + i
                    );

            hospital.addPatient(patient);

            assertTrue(
                    hospital.allocateBed(
                            patientId,
                            bedNumber
                    )
            );
        }

        // Verify all 20 beds are occupied.
        assertEquals(
                20,
                hospital.getOccupiedBeds()
        );

        // Try to allocate another patient.
        Inpatient extraPatient =
                createInpatient(
                        "P999",
                        "Extra",
                        "Patient"
                );

        hospital.addPatient(extraPatient);

        boolean allocated =
                hospital.allocateBed(
                        "P999",
                        "B01"
                );

        assertFalse(allocated);

        // Still exactly 20 occupied beds.
        assertEquals(
                20,
                hospital.getOccupiedBeds()
        );
    }

    @Test
    void shouldAllowReleasedBedToBeAllocatedAgain() {

        Inpatient firstPatient =
                createInpatient(
                        "P008",
                        "First",
                        "Patient"
                );

        Inpatient secondPatient =
                createInpatient(
                        "P009",
                        "Second",
                        "Patient"
                );

        hospital.addPatient(firstPatient);
        hospital.addPatient(secondPatient);

        assertTrue(
                hospital.allocateBed(
                        "P008",
                        "B05"
                )
        );

        assertTrue(
                hospital.releaseBed("B05")
        );

        assertTrue(
                hospital.allocateBed(
                        "P009",
                        "B05"
                )
        );

        assertEquals(
                "B05",
                secondPatient.getBedNumber()
        );

        assertEquals(
                1,
                hospital.getOccupiedBeds()
        );
    }

    @Test
    void shouldReturnFalseWhenReleasingAvailableBed() {

        boolean result =
                hospital.releaseBed("B01");

        assertFalse(result);

        assertEquals(
                0,
                hospital.getOccupiedBeds()
        );
    }

    @Test
    void shouldRejectInvalidBedNumber() {

        Inpatient patient =
                createInpatient(
                        "P010",
                        "Test",
                        "Patient"
                );

        hospital.addPatient(patient);

        assertFalse(
                hospital.allocateBed(
                        "P010",
                        "B21"
                )
        );

        assertFalse(
                hospital.allocateBed(
                        "P010",
                        "B00"
                )
        );

        assertFalse(
                hospital.allocateBed(
                        "P010",
                        "ABC"
                )
        );

        assertEquals(
                0,
                hospital.getOccupiedBeds()
        );
    }

    @Test
    void shouldAcceptLowerCaseBedNumber() {

        Inpatient patient =
                createInpatient(
                        "P011",
                        "Lower",
                        "Case"
                );

        hospital.addPatient(patient);

        assertTrue(
                hospital.allocateBed(
                        "P011",
                        "b01"
                )
        );

        assertEquals(
                "B01",
                patient.getBedNumber()
        );
    }

    @Test
    void shouldRejectUnknownPatient() {

        boolean result =
                hospital.allocateBed(
                        "P999",
                        "B01"
                );

        assertFalse(result);

        assertEquals(
                0,
                hospital.getOccupiedBeds()
        );
    }
}
